---
name: "❓Support request"
about: Questions and requests for support
labels: question
---

🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑

Please do not file questions or support requests on the GitHub issues tracker.

You can get your questions answered using other communication channels such as Slack (edgexfoundry.slack.com)

Thank you!

🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑
