# Repository Owners

This repository is managed by the EdgeX Device Services Working Group.  As such, the **Device Services Working Group** chairman is considered the "owner" of the repository and approves all committers of the repository.

See the [project Wiki TSC page](https://wiki.edgexfoundry.org/pages/viewpage.action?pageId=329436#TechnicalSteeringCommittee(TSC)-WorkingGroups) for information on the current EdgeX TSC and who occupies the role of Device Service Working Group chair.

For a complete list of current committers see:  https://github.com/orgs/edgexfoundry/teams/device-sdk-go-committers/members.

