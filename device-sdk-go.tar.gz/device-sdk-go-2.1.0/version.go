// -*- Mode: Go; indent-tabs-mode: t -*-
//
// Copyright (C) 2019 IOTech Ltd
//
// SPDX-License-Identifier: Apache-2.0

package device

// Global version for device-sdk-go
var Version string = "to be replaced by makefile"
